let gameseq=[];
let userseq=[];

let scorearr=[];

let btns=["yellow","red","purple","green"];
let started=false;
let level=0;

let h2=document.querySelector("h2");


document.addEventListener("keypress",function(){
    if(started==false)
    {
    console.log("game started");
    started=true;
    levelup();
    }
    });


function btnflash(btn){

    btn.classList.add("flash");

    setTimeout(function()
    {
        btn.classList.remove("flash")
    } , 400);

}

function userflash(btn){
    btn.classList.add("userflash");
    setTimeout(function()
    {
        btn.classList.remove("userflash");
    },400);
}


function levelup(){
    userseq=[];
    level++;
    h2.innerText=`Level ${level}`;
    scorearr.push(level);
    console.log(`Score =`,scorearr);

    
    //choose random button from btns[]
    let randindex=Math.floor(Math.random()*3);
    let randcolor=btns[randindex];//random index --2
     let randbtn=document.querySelector(`.${randcolor}`); //color wala class at index 2 and its button
    
      gameseq.push(randcolor);
      console.log("follow this:",gameseq);
    btnflash(randbtn);
}


function checkans(indx){
  if(gameseq[indx]==userseq[indx])
    {if(gameseq.length==userseq.length)
        {
            setTimeout(levelup,900);
        }
    
    }else{
        h2.innerText="game over!! Press any key to start";
        let bd=document.querySelector("body");
        bd.classList.add("bodycolor");
        
        setTimeout(function(){
            bd.classList.remove("bodycolor");
        },400);

        let sc=document.querySelector(".Score");
        sc.innerText=`Score=${level}`;
        
        setTimeout(function(){
            sc.innerText="Score=0";
        },1000);

        highscore();

       reset();
    }
}




function btnpress(){
    console.log(this);
    let btn=this;
    userflash(btn);
    // console.log("button was pressed");
    
    let usercolor=btn.getAttribute("id");
    userseq.push(usercolor);
    console.log(` user selection `,userseq);
    
    checkans(userseq.length-1);

}





let allbtns=document.querySelectorAll(".btn");
for(butt of allbtns){
    butt.addEventListener("click",btnpress);
}


function reset(){
    started=false;
    gameseq=[];
    userseq=[];
    level=0;
    
  
}

function highscore(){
     let tag=document.querySelector(".highscore");
    let high=0;
    for(let i=0;i<scorearr.length;i++){
       if(scorearr[i]>high){
        high=scorearr[i];
       
        tag.innerText=`High Score= ${high}`;
       }
    }
}